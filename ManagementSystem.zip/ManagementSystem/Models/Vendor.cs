﻿using System.ComponentModel.DataAnnotations;

namespace ManagementSystem.Models
{
    public class Vendor
    {
            public int Id { get; set; }
            [Required]
            public string Name { get; set; }
            [Required]
            [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Vendor Code must be alphanumeric.")]
            public string VendorCode { get; set; }
            [Required]
            public string Region { get; set; }
            [Required]
            [EmailAddress]
            public string Email { get; set; }
            public string Address { get; set; }
            [Required]
            [RegularExpression(@"^\d{10}$", ErrorMessage = "Invalid Mobile Number.")]
            public string PhoneNumber { get; set; }
            [Required]
            public string PrimaryContactName { get; set; }
        

    }
}
