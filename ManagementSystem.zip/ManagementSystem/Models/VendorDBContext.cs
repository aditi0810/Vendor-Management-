﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace ManagementSystem.Models
{
    public class VendorDBContext : DbContext
    {
       
            public VendorDBContext(DbContextOptions<VendorDBContext> options) : base(options) { }

            public DbSet<Vendor> Vendors { get; set; }
        

    }
}
