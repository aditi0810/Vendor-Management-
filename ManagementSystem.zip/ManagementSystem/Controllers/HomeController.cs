using ManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using System.Diagnostics;

namespace ManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly VendorDBContext venderDB;

        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}


        public HomeController(VendorDBContext venderDB)
        {
            this.venderDB = venderDB;
        }

        public async Task<IActionResult> Index()
        {
            var vendorData = await venderDB.Vendors.ToListAsync();
            return View(vendorData);
        }
        public IActionResult Create()
        {

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Vendor ven)
        {
            if (ModelState.IsValid)
            {
                await venderDB.Vendors.AddAsync(ven);
                await venderDB.SaveChangesAsync();
                TempData["insert_success"] = "Inserted..";
                return RedirectToAction("Index", "Home");

            }

            return View(ven);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || venderDB.Vendors == null)
            {
                return NotFound();
            }
            var vendorData = await venderDB.Vendors.FindAsync(id);
            if (vendorData == null)
            {
                return NotFound();
            }
            return View(vendorData);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, Vendor ven)
        {
            if (id != ven.Id)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                venderDB.Update(ven);
                await venderDB.SaveChangesAsync();
                TempData["update_success"] = "Updated..";
                return RedirectToAction("Index", "Home");
            }
            return View(ven);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || venderDB.Vendors == null)
            {
                return NotFound();
            }

            var vendorData = await venderDB.Vendors.FirstOrDefaultAsync(x => x.Id == id);
            if (vendorData == null)
            {
                return NotFound();
            }
            return View(vendorData);
        }
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int? id)
        {
            var vendorData = await venderDB.Vendors.FindAsync(id);
            if (vendorData != null)
            {
                venderDB.Vendors.Remove(vendorData);
            }
            await venderDB.SaveChangesAsync();
            TempData["delete_success"] = "Deleted..";

            return RedirectToAction("Index", "Home");

        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
